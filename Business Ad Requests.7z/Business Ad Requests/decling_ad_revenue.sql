use db;
WITH yearly_data AS (
    SELECT
        city_id,
        yr AS year,
        SUM(yearly_net_circulation) AS yearly_net_circulation,
        SUM(yearly_ad_revenue) AS yearly_ad_revenue
    FROM (
        -- Print circulation by year
        SELECT
            city_id,
            print_year AS yr,
            SUM(net_circulation) AS yearly_net_circulation,
            0 AS yearly_ad_revenue
        FROM combined_data
        WHERE print_year BETWEEN 2019 AND 2024
        GROUP BY city_id, print_year

        UNION ALL

        -- Ad revenue by year
        SELECT
            city_id,
            ad_year AS yr,
            0 AS yearly_net_circulation,
            SUM(ad_revenue_inr) AS yearly_ad_revenue
        FROM combined_data
        WHERE ad_year BETWEEN 2019 AND 2024
        GROUP BY city_id, ad_year
    ) t
    GROUP BY city_id, yr
),
ranked AS (
    SELECT
        city_id,
        year,
        yearly_net_circulation,
        yearly_ad_revenue,
        FIRST_VALUE(yearly_net_circulation) OVER (PARTITION BY city_id ORDER BY year) AS first_net,
        LAST_VALUE(yearly_net_circulation) OVER (
            PARTITION BY city_id ORDER BY year 
            ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING
        ) AS last_net,
        FIRST_VALUE(yearly_ad_revenue) OVER (PARTITION BY city_id ORDER BY year) AS first_ad,
        LAST_VALUE(yearly_ad_revenue) OVER (
            PARTITION BY city_id ORDER BY year 
            ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING
        ) AS last_ad
    FROM yearly_data
)
SELECT
    city_id AS city_name,
    year,
    yearly_net_circulation,
    yearly_ad_revenue,
    CASE WHEN last_net < first_net THEN 'Yes' ELSE 'No' END AS is_declining_print,
    CASE WHEN last_ad < first_ad THEN 'Yes' ELSE 'No' END AS is_declining_ad_revenue,
    CASE WHEN last_net < first_net AND last_ad < first_ad
         THEN 'Yes' ELSE 'No' END AS is_declining_both
FROM ranked
ORDER BY city_id, year;

