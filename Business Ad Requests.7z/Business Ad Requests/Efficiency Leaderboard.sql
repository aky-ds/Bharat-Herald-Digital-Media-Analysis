select * from fact_print_sales;
WITH city_efficiency AS (
    SELECT
        City_ID AS city_name,   -- or join with a city lookup table if you have one
        SUM("Copies Sold") AS copies_printed_2024,
        SUM(Net_Circulation) AS net_circulation_2024,
        CASE 
            WHEN SUM("Copies Sold") = 0 THEN 0
            ELSE ROUND(SUM(Net_Circulation) * 1.0 / SUM("Copies Sold"), 4)
        END AS efficiency_ratio
    FROM fact_print_sales
    WHERE Year = 2024
    GROUP BY City_ID
)
SELECT
    city_name,
    copies_printed_2024,
    net_circulation_2024,
    efficiency_ratio,
    RANK() OVER (ORDER BY efficiency_ratio DESC) AS efficiency_rank_2024
FROM city_efficiency
ORDER BY efficiency_rank_2024
LIMIT 5;
