select * from fact_digital_pilot;
WITH city_quarter_rates AS (
    SELECT
        city_id AS city_name,
        CASE 
            WHEN SUBSTRING(launch_month, 6, 2) IN ('01','02','03') THEN 'Q1'
            WHEN SUBSTRING(launch_month, 6, 2) IN ('10','11','12') THEN 'Q4'
        END AS quarter,
        SUM(downloads_or_accesses) * 1.0 / NULLIF(SUM(users_reached),0) AS internet_rate
    FROM fact_digital_pilot
    WHERE Year = 2021
      AND SUBSTRING(launch_month, 6, 2) IN ('01','02','03','10','11','12')
    GROUP BY city_id, quarter
),
pivoted AS (
    SELECT
        city_name,
        MAX(CASE WHEN quarter = 'Q1' THEN internet_rate END) AS internet_rate_q1_2021,
        MAX(CASE WHEN quarter = 'Q4' THEN internet_rate END) AS internet_rate_q4_2021
    FROM city_quarter_rates
    GROUP BY city_name
)
SELECT
    city_name,
    ROUND(internet_rate_q1_2021,4) AS internet_rate_q1_2021,
    ROUND(internet_rate_q4_2021,4) AS internet_rate_q4_2021,
    ROUND(COALESCE(internet_rate_q4_2021,0) - COALESCE(internet_rate_q1_2021,0),4) AS delta_internet_rate
FROM pivoted
ORDER BY delta_internet_rate DESC;
