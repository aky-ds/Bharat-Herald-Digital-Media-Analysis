use db;
WITH category_revenue_cte AS (
    SELECT
        Year AS year,
        ad_category AS category_name,
        SUM(Ad_revenue_inr) AS category_revenue
    FROM fact_ad_revenue
    GROUP BY Year, ad_category
),
yearly_total_cte AS (
    SELECT
        year,
        SUM(category_revenue) AS total_revenue_year
    FROM category_revenue_cte
    GROUP BY year
)
SELECT
    c.year,
    c.category_name,
    c.category_revenue,
    y.total_revenue_year,
    ROUND((c.category_revenue * 100.0 / y.total_revenue_year), 2) AS pct_of_year_total
FROM category_revenue_cte c
JOIN yearly_total_cte y
    ON c.year = y.year
ORDER BY c.year, pct_of_year_total DESC;
