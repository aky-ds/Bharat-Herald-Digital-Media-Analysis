WITH ordered_sales AS (
    SELECT 
        City_ID,
        State,
        Year,
        Month,
        Net_Circulation,
        LAG(Net_Circulation) OVER (PARTITION BY City_ID ORDER BY Year, 
            FIELD(Month,'January','February','March','April','May','June',
                  'July','August','September','October','November','December')) AS prev_net_circ
    FROM fact_print_sales
    WHERE Year BETWEEN 2019 AND 2024
),
declines AS (
    SELECT 
        City_ID,
        State,
        Year,
        Month,
        Net_Circulation,
        prev_net_circ,
        (Net_Circulation - prev_net_circ) AS change_in_circ
    FROM ordered_sales
    WHERE prev_net_circ IS NOT NULL
      AND Net_Circulation < prev_net_circ
)
SELECT 
    City_ID,
    State,
    Year,
    Month,
    Net_Circulation,
    prev_net_circ,
    change_in_circ
FROM declines
ORDER BY change_in_circ ASC
LIMIT 3;
